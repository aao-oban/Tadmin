===================
Tadmin v2.0.1 By OBAN
===================

12/22/2023


Changelog V2.0.1:

-added function to define the AI skill level of the bots at the start of the game

To set the default AI level follow the steps below:

**1 Stop your server
**2 Copy the Tadmin.u and tadmin.ini files corresponding to version 2.0.1 of tadmin to the system folder of your server
**3 Edit the following parameters of the Tadmin.ini file

	Enable_AI_skill_cmd=True
	start_with_AI_level_established=True
	AI_level=[x] Where X could be 0 1 2 3 4
	
	0=Easiest, 1=Easier 2=Default 3=Harder 4=Max

**4 Save changes to the Tadmin.ini file
**5 Start your server


Changelog V2.0.0:

-improvements to some Tadmin messages
-added the "sammo" command that is used to summon random ammunition when bots die in action
-fixed problem with a function that interfered with the server .ini configuration file
-tadmin changeclass command enhancements

Changelog v1.9.1:

-fixed the cmd "setini S_cheats [x]"


Changelog v1.9:

-Added "aiskill" command (command used to control the level of "AI difficulty")
-fixed bugs of "prammo" command
-improvements to the prammo command (now this command gives more grenades and also gives medpacks)


SAMMO CMD

The SAMMO command comes from the words Summon and Ammo. This command has been designed so that players can play the game without using the cheat paramsammo 1 that gives infinite ammunition. The sammo command spawns ammo near where the bot's weapon lands so the player can pick up that ammo and complete the map without using cheats.

when using the samo command, all players have the m4a1mod weapon, additionally this command disables the use of cheats on the server

how to use aiskill command

	cmd sintax:	samo [x]	Where x can be 1 to enable or 0 to disable

Example:

		mutate samo 1	(enable de samo cmd)



AISKILL CMD

The behavior of the bots in the game is controlled by the "AI Difficulty". There are 5 levels for the "AI Difficulty" (level 0 Easiest, level 1 Easier, level 2 Default, level 3 Harder, level 4 Max)

Every time a match is started, the game automatically chooses the "AI Difficulty" level based on various parameters such as number of players, skill of the players, duration of a previous match, etc.

The common thing is to start a round with level 2 (default) but if we don't complete the mission in the round, when the next round starts the game automatically will lower the level of "AI difficulty" to level 0 or Level 1. But if we complete the mission too easily, then the game will increase the "AI Difficulty" level to level 3 or 4 in the next round

As explained above, "AI Difficulty" is something that the game controls automatically, the aiskill command is for players to set the level of "AI difficulty".

how to use aiskill command

	cmd sintax:	aiskill [x]	Where x can be: x=0,x=1,x=2,x=3,x=4,X=off


		x=0 to set the level to Easiest
		x=1 to set the level to Easier
		x=2 to set the level to Default
		x=3 to set the level to Harder
		x=4 to set the level to Max
		x=off to disable the command

Example:

		mutate aiskill 4	(set the AI skill to Max Level)


Important note: the aiskill command must be used only once until you switch to another map where the command must be used again to adjust the level of the "AI Difficulty"



PRAMMO CMD

This command allows players when picking up an enemy weapon to obtain more ammo, as well as a random number of various types of grenades and medpacks.

The PRAMMO command comes from the words Pick up Random Ammunition. This command has been designed to stop using the cheat to get unlimited ammo in the game and also to give some more realism to the game since at the moment of picking up the enemy weapon it is as if you were checking the enemy's body for ammunition, grenades and medpacks.

how to use aiskill command

	cmd sintax:	prammo [x]	Where x can be: x=0,x=1


		x=1 to enable the cmd
		x=0 to disable the cmd

Example:

		mutate prammo 1		(Enable the cmd)

